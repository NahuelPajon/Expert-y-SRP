using System;
using System.Text;

namespace Library
{
    public class NumberDate
    {
        public static int GenerateNumber=0;
        
        public void Incrementar()
        {
            GenerateNumber++;
        }

        public int GetNumber()
        {
            return GenerateNumber;
        }
        
    }
}