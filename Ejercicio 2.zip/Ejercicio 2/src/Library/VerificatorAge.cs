using System;
using System.Text;

namespace Library
{
    public class VerificatorAge
    {
        public static string VerificateAge(DateTime date)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (date.Year > 2002)
            {
                stringBuilder.Append("You are not old enough to make an appointment");
            }
            else
            {
                stringBuilder.Append("You are old enough to make an appointment");
            }

            return stringBuilder.ToString();
        }

    }
}
