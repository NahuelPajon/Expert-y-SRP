﻿using System;
using System.Text;

namespace Library
{
    public class AppointmentService
    {
        public static string CreateAppointment(string name, string id, string phoneNumber, DateTime date, string appoinmentPlace, string doctorName, string doctorType)
        {
            StringBuilder stringBuilder = new StringBuilder("Scheduling appointment...\n");
            
            Boolean isValid = true;

            if (string.IsNullOrEmpty(name))
            {
                stringBuilder.Append("Unable to schedule appointment, 'name' is required\n");
                isValid = false;
            }

            if (string.IsNullOrEmpty(id))
            {
                stringBuilder.Append("Unable to schedule appointment, 'id' is required\n");
                isValid = false;
            }

            if (string.IsNullOrEmpty(phoneNumber))
            {
                stringBuilder.Append("Unable to schedule appointment, 'phone number' is required\n");
                isValid = false;
            }

            if (string.IsNullOrEmpty(date.ToString()))
            {
                stringBuilder.Append("Unable to schedule appointment, 'date' is required\n");
                isValid = false;
            }

            if (string.IsNullOrEmpty(appoinmentPlace))
            {
                stringBuilder.Append("Unable to schedule appointment, 'appoinment place' is required\n");
                isValid = false;
            }


            if (string.IsNullOrEmpty(doctorName))
            {
                stringBuilder.Append("Unable to schedule appointment, 'doctor name' is required\n");
                isValid = false;
            }

            
            if (string.IsNullOrEmpty(doctorType))
            {
                stringBuilder.Append(IdentificateDoctor.ChooseDoctorInteraction(doctorType));
                
            }

            if (isValid)
            {
                stringBuilder.Append("Appoinment scheduled\n");
                NumberDate generateNumber = new NumberDate();
                generateNumber.Incrementar();
                int ejecuciones = generateNumber.GetNumber();
                stringBuilder.Append($"Your appointment number is: {ejecuciones}\n");
            }
            

            return stringBuilder.ToString();
        }

    }
}
