using System;
using System.Text;

namespace Library
{
    public class IdentificateDoctor
    {
        public static string ChooseDoctorInteraction(string doctorType)
        {
            StringBuilder stringbuilder = new StringBuilder();
            if (string.IsNullOrEmpty(doctorType))
            {
                Console.WriteLine("Why do you want a Doctor?");
                Console.WriteLine("1. For leg problems");
                Console.WriteLine("2. For Headaches");
                Console.WriteLine("3. For Heart problems");
                Console.WriteLine("Choose a number");
                string numberDoctor= Console.ReadLine();
                if (numberDoctor=="1")
                {
                    Console.WriteLine(ChooseDoctor(true,false,false));
                }
                if (numberDoctor=="2")
                {
                    Console.WriteLine(ChooseDoctor(false, true, false));
                }
                if (numberDoctor=="3")
                {
                    Console.WriteLine(ChooseDoctor(false, false, true));
                }

            }
            return stringbuilder.ToString();
        }



        public static string ChooseDoctor(bool doctor1, bool doctor2, bool doctor3)
        {
            StringBuilder doctors= new StringBuilder();
            if (doctor1)
            {
                doctors.Append("Your Doctor is specialist in leg problems");
            }
            if (doctor2)
            {
                doctors.Append("Your Doctor is specialist in Headaches");
            }
            if (doctor3)
            {
                doctors.Append("Your Doctor is specialist in Heart problems");
            }
            return doctors.ToString();
        }
    }
}