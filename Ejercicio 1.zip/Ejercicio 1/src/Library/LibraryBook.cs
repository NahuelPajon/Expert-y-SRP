using System;

namespace SRP
{
    public class ShelveBook
    {

        public string LibrarySector { get ; set; }
        public string LibraryShelve { get ; set; }
        public Book Book { get ; set; }

        public ShelveBook(String sector, String shelve, Book book)
        {
            this.Book = book;
            this.LibrarySector = sector;
            this.LibraryShelve = shelve;
        }
    }
}
