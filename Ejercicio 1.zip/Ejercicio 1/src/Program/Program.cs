﻿using System;

namespace SRP
{

    class Program
    {
        static void Main()
        {
            Book book1 = new Book("Design Patterns","Erich Gamma & Others","001-034"); // crea el libro1
            Book book2 = new Book("Pro C#","Troelsen","001-035"); // crea el libro2
            
            ShelveBook shelvebook1= new ShelveBook("A","7", book1); // ordena el libro1, lo ubica en el sector A, estante 7
            ShelveBook shelvebook2= new ShelveBook("B","3", book2); // ordena el libro2, lo ubica en el sector B, estante 3

        }
    }
}